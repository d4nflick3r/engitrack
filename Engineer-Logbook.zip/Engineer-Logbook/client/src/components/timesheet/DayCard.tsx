import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { DayEntry, TimeBlock } from "@/hooks/use-timesheet";
import { format, parseISO } from "date-fns";
import { calculateDayHours } from "@/lib/calculations";

interface DayCardProps {
  day: DayEntry;
  index: number;
  updateDay: (index: number, updates: Partial<DayEntry>) => void;
  updateTimeBlock: (dayIndex: number, blockIndex: number, field: keyof TimeBlock, value: string) => void;
}

export function DayCard({ day, index, updateDay, updateTimeBlock }: DayCardProps) {
  const date = parseISO(day.date);
  const dayName = format(date, 'EEEE');
  const shortDate = format(date, 'MMM d');
  const hours = calculateDayHours(day);

  return (
    <Card className={`relative overflow-hidden transition-all duration-200 ${day.isDayOff ? 'opacity-60 bg-muted/50' : 'bg-card'}`}>
      <div className={`absolute top-0 left-0 w-1.5 h-full ${day.isBankHoliday ? 'bg-purple-500' : index > 4 ? 'bg-orange-400' : 'bg-blue-500'}`} />
      
      <CardHeader className="pb-3 pt-4 px-5 flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-lg font-bold flex items-center gap-2">
            {dayName} <span className="text-sm font-normal text-muted-foreground">{shortDate}</span>
          </CardTitle>
        </div>
        <div className="flex items-center gap-5 text-sm">
          <div className="flex items-center gap-2">
            <Switch 
              id={`bh-${index}`}
              checked={day.isBankHoliday} 
              onCheckedChange={(c) => updateDay(index, { isBankHoliday: c, isDayOff: c ? false : day.isDayOff })}
            />
            <Label htmlFor={`bh-${index}`} className="cursor-pointer text-purple-600 font-medium">Bank Holiday</Label>
          </div>
          <div className="flex items-center gap-2 border-l pl-5">
            <Switch 
              id={`off-${index}`}
              checked={day.isDayOff} 
              onCheckedChange={(c) => updateDay(index, { isDayOff: c })}
            />
            <Label htmlFor={`off-${index}`} className="cursor-pointer">Day Off</Label>
          </div>
        </div>
      </CardHeader>
      
      {!day.isDayOff && (
        <CardContent className="px-5 pb-5 space-y-4">
          <div className="space-y-3">
            <div className="flex items-end gap-2 sm:gap-4">
              <div className="grid gap-1.5 flex-1">
                <Label className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">Start Time</Label>
                <Input 
                  type="time" 
                  value={day.timeBlocks[0].startTime} 
                  onChange={(e) => updateTimeBlock(index, 0, 'startTime', e.target.value)}
                  className="font-mono text-base h-10"
                />
              </div>
              <div className="grid gap-1.5 flex-1">
                <Label className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">End Time</Label>
                <Input 
                  type="time" 
                  value={day.timeBlocks[0].endTime} 
                  onChange={(e) => updateTimeBlock(index, 0, 'endTime', e.target.value)}
                  className="font-mono text-base h-10"
                />
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-end gap-3 pt-2">
            <div className="flex items-center gap-3 bg-slate-50 px-3 py-1.5 rounded-md border">
              <Label className="text-xs font-medium text-slate-600 whitespace-nowrap">Unpaid Break (min):</Label>
              <Input 
                type="number" 
                min="0"
                step="15"
                value={day.breakMinutes} 
                onChange={(e) => updateDay(index, { breakMinutes: parseInt(e.target.value) || 0 })}
                className="w-20 h-8 font-mono text-right"
              />
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
