import { useState, useEffect } from 'react';
import { startOfWeek, addDays, format, parseISO } from 'date-fns';

export interface TimeBlock {
  startTime: string; // "08:00"
  endTime: string;   // "17:00"
}

export interface DayEntry {
  date: string; // ISO yyyy-MM-dd
  isDayOff: boolean;
  isBankHoliday: boolean;
  timeBlocks: TimeBlock[];
  breakMinutes: number;
}

export interface TimesheetState {
  weekStartDate: string; // ISO yyyy-MM-dd
  baseRate: number;
  standardHoursPerDay: number;
  submitEmail?: string;
  days: DayEntry[];
  repairs: { count: number; notes: string };
  extraJobs: { count: number; notes: string };
}

const defaultState = (startDate: Date): TimesheetState => {
  const days: DayEntry[] = [];
  for (let i = 0; i < 7; i++) {
    const date = addDays(startDate, i);
    const isWeekend = i === 5 || i === 6;
    days.push({
      date: format(date, 'yyyy-MM-dd'),
      isDayOff: isWeekend,
      isBankHoliday: false,
      timeBlocks: [{ startTime: isWeekend ? '' : '08:00', endTime: isWeekend ? '' : '17:00' }],
      breakMinutes: isWeekend ? 0 : 60,
    });
  }
  
  return {
    weekStartDate: format(startDate, 'yyyy-MM-dd'),
    baseRate: 15.00,
    standardHoursPerDay: 8,
    submitEmail: '',
    days,
    repairs: { count: 0, notes: '' },
    extraJobs: { count: 0, notes: '' },
  };
};

export function useTimesheet() {
  const [state, setState] = useState<TimesheetState>(() => {
    const saved = localStorage.getItem('timesheet-state');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    const monday = startOfWeek(new Date(), { weekStartsOn: 1 });
    return defaultState(monday);
  });

  useEffect(() => {
    localStorage.setItem('timesheet-state', JSON.stringify(state));
  }, [state]);

  const resetWeek = (newStartDate?: string) => {
    const monday = newStartDate ? parseISO(newStartDate) : startOfWeek(new Date(), { weekStartsOn: 1 });
    setState(defaultState(monday));
  };

  const updateDay = (index: number, updates: Partial<DayEntry>) => {
    setState(s => {
      const newDays = [...s.days];
      newDays[index] = { ...newDays[index], ...updates };
      return { ...s, days: newDays };
    });
  };
  
  const updateTimeBlock = (dayIndex: number, blockIndex: number, field: keyof TimeBlock, value: string) => {
    setState(s => {
      const newDays = [...s.days];
      const newBlocks = [...newDays[dayIndex].timeBlocks];
      newBlocks[blockIndex] = { ...newBlocks[blockIndex], [field]: value };
      newDays[dayIndex] = { ...newDays[dayIndex], timeBlocks: newBlocks };
      return { ...s, days: newDays };
    });
  };

  const addTimeBlock = (dayIndex: number) => {
    setState(s => {
      const newDays = [...s.days];
      newDays[dayIndex] = { ...newDays[dayIndex], timeBlocks: [...newDays[dayIndex].timeBlocks, { startTime: '', endTime: '' }] };
      return { ...s, days: newDays };
    });
  };

  const removeTimeBlock = (dayIndex: number, blockIndex: number) => {
    setState(s => {
      const newDays = [...s.days];
      const newBlocks = newDays[dayIndex].timeBlocks.filter((_, i) => i !== blockIndex);
      newDays[dayIndex] = { ...newDays[dayIndex], timeBlocks: newBlocks };
      return { ...s, days: newDays };
    });
  };

  const setBaseRate = (rate: number) => setState(s => ({ ...s, baseRate: rate }));
  const setStandardHoursPerDay = (hours: number) => setState(s => ({ ...s, standardHoursPerDay: hours }));
  const setRepairs = (updates: Partial<TimesheetState['repairs']>) => setState(s => ({ ...s, repairs: { ...s.repairs, ...updates } }));
  const setExtraJobs = (updates: Partial<TimesheetState['extraJobs']>) => setState(s => ({ ...s, extraJobs: { ...s.extraJobs, ...updates } }));
  const setSubmitEmail = (email: string) => setState(s => ({ ...s, submitEmail: email }));

  // Helper for bank holidays
  const markBankHolidays = (bankHolidayDates: string[]) => {
    setState(s => {
      const newDays = s.days.map(d => ({
        ...d,
        isBankHoliday: bankHolidayDates.includes(d.date) ? true : d.isBankHoliday
      }));
      return { ...s, days: newDays };
    });
  };

  return { state, resetWeek, updateDay, updateTimeBlock, addTimeBlock, removeTimeBlock, setBaseRate, setStandardHoursPerDay, setRepairs, setExtraJobs, setSubmitEmail, markBankHolidays };
}
