import { useTimesheet } from "@/hooks/use-timesheet";
import { UK_BANK_HOLIDAYS, calculateSummary, calculateDayHours } from "@/lib/calculations";
import { DayCard } from "@/components/timesheet/DayCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Settings2, RotateCcw, Download, Calendar as CalendarIcon, Briefcase, Wrench, HardHat, Mail, Copy, CheckCircle2 } from "lucide-react";
import { format, parseISO } from "date-fns";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

export default function Home() {
  const { 
    state, resetWeek, updateDay, updateTimeBlock, addTimeBlock, removeTimeBlock, 
    setBaseRate, setStandardHoursPerDay, setRepairs, setExtraJobs, setSubmitEmail, markBankHolidays 
  } = useTimesheet();

  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [generatedCsvContent, setGeneratedCsvContent] = useState("");
  const [copied, setCopied] = useState(false);

  const isValidEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const handleCopyCsv = () => {
    navigator.clipboard.writeText(generatedCsvContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = () => {
    if (!isValidEmail(state.submitEmail || '')) return;

    const summary = calculateSummary(state);
    
    let csv = "EngiTrack Weekly Timesheet Export\n";
    csv += `Week Commencing,${state.weekStartDate}\n\n`;
    
    csv += "Date,Day,Start Time,End Time,Break (mins),Total Hours,Bank Holiday,Day Off\n";
    state.days.forEach(d => {
      const date = parseISO(d.date);
      const dayHours = calculateDayHours(d);
      const start = d.timeBlocks[0]?.startTime || '';
      const end = d.timeBlocks[0]?.endTime || '';
      csv += `${d.date},${format(date, 'EEEE')},${start},${end},${d.breakMinutes},${dayHours.toFixed(2)},${d.isBankHoliday ? 'Yes' : 'No'},${d.isDayOff ? 'Yes' : 'No'}\n`;
    });
    
    csv += `\nWeekly Totals\n`;
    csv += `Total Hours,${summary.hours.total.toFixed(2)}\n`;
    csv += `Standard Hours (Mon-Fri),${summary.hours.standardHours.toFixed(2)}\n`;
    csv += `Weekday Overtime,${summary.hours.weekdayOvertime.toFixed(2)}\n`;
    csv += `Saturday Hours,${summary.hours.saturdayHours.toFixed(2)}\n`;
    csv += `Sunday Hours,${summary.hours.sundayHours.toFixed(2)}\n`;
    csv += `Bank Holiday Hours,${summary.hours.bankHolidayHours.toFixed(2)}\n\n`;

    csv += `Repairs Logged,${state.repairs.count}\n`;
    csv += `Repairs Notes,"${state.repairs.notes.replace(/"/g, '""')}"\n\n`;
    csv += `Extra Jobs Logged,${state.extraJobs.count}\n`;
    csv += `Extra Jobs Notes,"${state.extraJobs.notes.replace(/"/g, '""')}"\n`;
    
    setGeneratedCsvContent(csv);

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `timesheet-${state.weekStartDate}.csv`;
    a.click();

    setIsSubmitModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20 font-sans">
      <header className="bg-white border-b border-border sticky top-0 z-20 shadow-sm">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg shadow-sm">
              <HardHat className="h-5 w-5 text-white" />
            </div>
            <h1 className="text-xl font-extrabold tracking-tight text-slate-900 hidden sm:block">EngiTrack</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => markBankHolidays(UK_BANK_HOLIDAYS)} className="hidden sm:flex" title="Auto-fill England & Wales Bank Holidays">
              <CalendarIcon className="h-4 w-4 mr-2" /> Bank Holidays
            </Button>
            <Button variant="outline" size="sm" onClick={() => resetWeek()}>
              <RotateCcw className="h-4 w-4 mr-2" /> Reset
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-8">
            <Card className="shadow-sm border-slate-200">
              <CardHeader className="pb-4 border-b bg-slate-50/50">
                <CardTitle className="text-lg flex items-center gap-2 font-bold text-slate-800">
                  <Settings2 className="h-5 w-5 text-slate-500" />
                  Timesheet Settings
                </CardTitle>
                <CardDescription>Configure your base rate and weekly setup</CardDescription>
              </CardHeader>
              <CardContent className="pt-5 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="font-semibold text-slate-700">Week Commencing (Mon)</Label>
                  <Input 
                    type="date" 
                    value={state.weekStartDate}
                    onChange={(e) => resetWeek(e.target.value)}
                    className="font-mono text-base"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-semibold text-slate-700">Dedicated Email Address</Label>
                  <Input 
                    type="email" 
                    placeholder="manager@example.com"
                    value={state.submitEmail || ''}
                    onChange={(e) => setSubmitEmail(e.target.value)}
                    className="font-mono text-base"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="space-y-5">
              <div className="flex items-center gap-2">
                <CalendarIcon className="h-6 w-6 text-blue-600" />
                <h2 className="text-2xl font-bold tracking-tight text-slate-900">
                  Daily Logs
                </h2>
              </div>
              <div className="grid gap-5">
                {state.days.map((day, index) => (
                  <DayCard 
                    key={day.date} 
                    day={day} 
                    index={index} 
                    updateDay={updateDay}
                    updateTimeBlock={updateTimeBlock}
                  />
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-5 pt-4">
              <Card className="shadow-sm border-slate-200 border-t-4 border-t-green-500">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2 font-bold text-slate-800">
                    <Wrench className="h-5 w-5 text-green-600" />
                    Repairs (£10 ea)
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <Label className="font-semibold">Total Repairs Completed:</Label>
                    <Input 
                      type="number" 
                      min="0" 
                      value={state.repairs.count} 
                      onChange={(e) => setRepairs({ count: parseInt(e.target.value) || 0 })}
                      className="w-24 font-mono font-bold text-lg text-center"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold text-slate-700">Notes / Job References</Label>
                    <Textarea 
                      placeholder="e.g. Job #12345, Boiler swap" 
                      value={state.repairs.notes}
                      onChange={(e) => setRepairs({ notes: e.target.value })}
                      className="resize-none h-24 text-sm"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm border-slate-200 border-t-4 border-t-blue-500">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2 font-bold text-slate-800">
                    <Briefcase className="h-5 w-5 text-blue-600" />
                    Extra Jobs (£10 ea)
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <Label className="font-semibold">Extra Jobs Picked Up:</Label>
                    <Input 
                      type="number" 
                      min="0" 
                      value={state.extraJobs.count} 
                      onChange={(e) => setExtraJobs({ count: parseInt(e.target.value) || 0 })}
                      className="w-24 font-mono font-bold text-lg text-center"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm font-semibold text-slate-700">Notes / References</Label>
                    <Textarea 
                      placeholder="e.g. Emergency call out #98765" 
                      value={state.extraJobs.notes}
                      onChange={(e) => setExtraJobs({ notes: e.target.value })}
                      className="resize-none h-24 text-sm"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="pt-8 pb-4">
              <Button 
                size="lg" 
                className="w-full text-lg h-14 bg-blue-600 hover:bg-blue-700" 
                onClick={handleSubmit}
                disabled={!isValidEmail(state.submitEmail || '')}
              >
                <Download className="h-5 w-5 mr-2" /> Submit Timesheet
              </Button>
              {!isValidEmail(state.submitEmail || '') && (
                <p className="text-center text-sm text-slate-500 mt-2">
                  Please enter a valid dedicated email address in settings to submit.
                </p>
              )}
            </div>

        </div>
      </main>

      <Dialog open={isSubmitModalOpen} onOpenChange={setIsSubmitModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-green-600">
              <CheckCircle2 className="h-5 w-5" /> 
              Step 1 Complete: CSV Downloaded
            </DialogTitle>
            <DialogDescription className="pt-2 text-base text-slate-700">
              Your timesheet has been downloaded as <strong>timesheet-{state.weekStartDate}.csv</strong>.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4 space-y-4">
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
              <h4 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
                Step 2: Send via Email
              </h4>
              <p className="text-sm text-slate-600 mb-4">
                Click below to open a draft email to your manager. <strong>You will need to manually attach the downloaded CSV file</strong> before sending.
              </p>
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700" 
                onClick={() => {
                  const subject = encodeURIComponent(`Timesheet - ${state.weekStartDate}`);
                  const body = encodeURIComponent(`Please find attached the timesheet CSV for the week commencing ${state.weekStartDate}.`);
                  window.location.href = `mailto:${state.submitEmail}?subject=${subject}&body=${body}`;
                }}
              >
                <Mail className="h-4 w-4 mr-2" /> Open Email Draft
              </Button>
            </div>
            
            <div className="pt-2 border-t flex flex-col gap-2">
              <p className="text-xs text-center text-slate-500">
                If the download was blocked by your browser, you can copy the raw data instead:
              </p>
              <Button variant="outline" onClick={handleCopyCsv} className="w-full">
                {copied ? <CheckCircle2 className="h-4 w-4 mr-2 text-green-600" /> : <Copy className="h-4 w-4 mr-2" />}
                {copied ? "Copied to clipboard!" : "Copy CSV to Clipboard"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
